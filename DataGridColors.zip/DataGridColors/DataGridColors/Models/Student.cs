﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataGridColors
{
    public class Student
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        /*public string Garbage
        {
            get
            {
                return "n/a";
            }
            set
            {

            }
        }*/
        public string Grade { get; set; }

    }
}
