﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prism.Mvvm;

namespace DataGridColors
{
    public class MainWindowViewModel : BindableBase
    {
        private ObservableCollection<Student> _students;
        public ObservableCollection<Student> Students
        {
            get
            {
                return _students;
            }
            set
            {
                SetProperty(ref _students, value);
            }
        }
        public MainWindowViewModel()
        {
            Students = new ObservableCollection<Student>();
            Student first = new Student();
            first.FirstName = "John";
            first.LastName = "Smith";
            first.Grade = "A";
            Student second = new Student();
            second.FirstName = "Sally";
            second.LastName = "Johnson";
            second.Grade = "B";
            Student third = new Student();
            third.FirstName = "Bill";
            third.LastName = "Taylor";
            third.Grade = "F";
            Student fourth = new Student();
            fourth.FirstName = "Amy";
            fourth.LastName = "Simpson";
            fourth.Grade = "D";
            Students.Add(first);
            Students.Add(second);
            Students.Add(third);
            Students.Add(fourth);
        }
    }
}