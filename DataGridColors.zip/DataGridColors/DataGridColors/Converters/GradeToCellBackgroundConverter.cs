﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;

namespace DataGridColors
{
    public class GradeToCellBackgroundConverter : IMultiValueConverter
    {
        /// <summary>
        /// Converts content and column name of a cell into a background color
        /// </summary>
        /// <param name="value">[[0] = content of cell and [1] = name of column containing cell</param>
        /// <param name="targetType"></param>
        /// <param name="parameter"></param>
        /// <param name="culture"></param>
        /// <returns></returns>
        public object Convert(object[] value, Type targetType, object parameter, CultureInfo culture)
        {
            if(value[0].GetType() == typeof(string))
            {
                if (((string)value[1] == "Grade") && (((string)value[0] == "D") || ((string)value[0] == "F")))
                {
                    return (SolidColorBrush)(new BrushConverter().ConvertFrom("#EEAAAA")); ;
                }
            }
            return null;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
